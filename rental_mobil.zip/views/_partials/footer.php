<footer class="sticky-footer bg-white">
	<div class="container my-auto">
	    <div class="copyright text-center my-auto">
	    <span>
	    <a href="https://github.com/aldoalfiyanv" target="_blank">Pemrograman Web Lanjut</a> &copy; Aplikasi Rental Mobil <?= date('Y') ?></span>
	    </div>
	</div>
</footer>